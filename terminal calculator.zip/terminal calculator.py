# creating a calculator
import re


class Calculator:
    """
    employs parenthesis to indicate the order of action
     Implement all arithmatic operation
    """
    def calculate(self, y):
        #takes in a string y  and returns the number
        # for examples 6+2 ,1+(2+3)
        result = 0
        current =0
        sign = 1
        stack = []  # using the LIFO Principle
        for ss in y:
            if ss.isdigit():
                current = int(ss) + 10*current

            elif ss ["*", "/"]:
                print("this operation is not supported.")
                break
            elif ss in ["-", "+"]:
                result += sign * current
                current =0
                if ss == "+":
                    sign=1
                else:
                    sign=-1
            elif ss == "(":
                stack.append(result)
                stack.append(sign)
                sign =1
                result=0

            elif ss ==")":
                result += current * sign
                result *= stack.pop()
                result += stack.pop()
                current =0



        return result + current * sign
print(" Launching the calculator..")
calc = Calculator()
user_input = ""
while user_input not in ["exit", "quit", "stop","close"]:
    regex=re.search('[a-zA-Z]', user_input)
    if regex != None:
        print("plese write an expression")
    user_input = input(">")
    output = calc.calculate(user_input)
    print(input)
print("closing the calculator")


# note: all the packages are installed when executing